package com.citi.jpademos;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("jpacrud");
		EntityManager entityManager = factory.createEntityManager();
		// CRUD-->persist,merge,remove,find,getTransaction,begin,commit
		entityManager.getTransaction().begin();
		Employee emp = new Employee(123, "mahesh", "hyderabad", 9000);
		entityManager.persist(emp);// ORM//insert
		entityManager.getTransaction().commit();

	}

}
